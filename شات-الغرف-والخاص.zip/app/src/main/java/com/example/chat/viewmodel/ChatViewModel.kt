package com.example.chat.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.chat.model.ChatRoom
import com.example.chat.model.Message
import com.example.chat.model.User
import com.example.chat.service.FirebaseChatService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.random.Random

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("ChatPrefs", Context.MODE_PRIVATE)
    private val firebaseService = FirebaseChatService()

    // Default Rooms List
    val rooms = listOf(
        ChatRoom("r_general", "الدردشة العامة 💬", "المكان الأمثل للترحيب بالأعضاء الجدد ومناقشة مختلف المواضيع اليومية.", "all"),
        ChatRoom("r_tech", "عالم التكنولوجيا 💻", "هنا يلتقي المبرمجون وهواة التقنية لمناقشة البرمجة والذكاء الاصطناعي وجديد القطع التقنية.", "terminal"),
        ChatRoom("r_literature", "ديوانية الأدب والشعر 📖", "مساحة هادئة لمحبّي الكلمات الراقية، الشعر العربي الأصيل، والخواطر النفسية الجميلة.", "book"),
        ChatRoom("r_sports", "مقهى الرياضة ⚽", "عشاق الساحرة المستديرة ومختلف الرياضات! توقعات ونتائج المباريات وتغطية الكلاسيكو.", "sports")
    )

    // Simulation/Bot answers
    private val botMessageTemplates = mapOf(
        "user_bot_1" to listOf(
            "مرحباً بك في غرف الدردشة! كيف ترى جودة التصميم؟",
            "أنا صقر الصحراء، أفضل ما في هذا التطبيق هو دعمه الكامل للربط مع الفايربيس (Firebase)!",
            "يسعدني جداً التواجد هنا، الكود مكتوب بالكامل باستخدام Jetpack Compose.",
            "هل جربتم تغيير اسمكم في الإعدادات؟ ستتغير ألوانكم تلقائياً!",
            "الدردشة الكتابية ممتعة، ما رأيك في تطبيقنا؟"
        ),
        "user_bot_2" to listOf(
            "يا هلا والله! نورت الشات يا غالي.",
            "هل تعلمون أن التطبيق يحتوي على محاكاة ذكية للبرمجة والربط؟ جربوا استخدام فايربيس الخاص بكم.",
            "الأجواء الرياضية في مقهى الرياضة حماسية، الرياضة دائماً تجمعنا.",
            "الشواهد الأدبية غاية في الأناقة والجمال.",
            "تطبيق رائع جداً، متجاوب وسريع!"
        ),
        "user_bot_3" to listOf(
            "السلام عليكم ورحمة الله وبركاته، طاب يومكم يا أصدقاء.",
            "العلم كنز لا يزول، تذكروا الاستفادة من وقتكم في تعلم لغة الكوتلن الجميلة.",
            "تواصلوا معي عبر الدردشة الخاصة لمعرفة المزيد حول الربط بقاعدة بيانات الفاير بيز.",
            "اللغة العربية لغة الضاد وهي فخرنا واعتزازنا.",
            "التصميم يدعم الألوان والمظهر الليلي بشكل ممتع لحماية العين."
        ),
        "user_bot_4" to listOf(
            "أهلاً وسهلاً بكم! يوم سعيد للجميع.",
            "الأمل هو منارة الحياة، ومشاركتكم في هذا الشات تزيدنا سعادة.",
            "الدردشة الخاصة تعمل بشكل ممتاز، جرب الضغط على اسمي والحديث معي خاصاً!",
            "الربط مع الفايربيس بسيط ولا يتطلب إعدادات معقدة بفضل نظام الواجهة الخلفية.",
            "دعونا نطرح سؤالاً تقنياً في غرفة التكنولوجيا!"
        )
    )

    private val generalBotRandomTalk = listOf(
        "البرمجة باستخدام الكوتلن (Kotlin) ومكتبة جيت باك كومبوز ممتعة وسريعة جداً!",
        "يا جماعة، هل رأيتم الإعدادات الرائعة للتطبيق؟ يمكنك تغيير الرابط في أي وقت.",
        "الفايربيس يوفر إمكانيات رهيبة للمزامنة الفورية عبر الـ REST API.",
        "أنا متحمس لتجربة التطبيق على هاتفي، السلاسة والسرعة استثنائية.",
        "جلسة هادئة هنا مع كوب من الشاي وقراءة بعض الأكواد المتقنة لا تقدر بثمن."
    )

    // Mock Users
    private val mockBots = listOf(
        User("user_bot_1", "صقر الصحراء 🦅", "#FF5722", System.currentTimeMillis(), true),
        User("user_bot_2", "نسمة برية 🌸", "#E91E63", System.currentTimeMillis(), true),
        User("user_bot_3", "عابر سبيل 🚶", "#9C27B0", System.currentTimeMillis(), true),
        User("user_bot_4", "بسمة الأمل ✨", "#4CAF50", System.currentTimeMillis(), true)
    )

    // SharedPreferences values
    private val _dbUrl = MutableStateFlow(prefs.getString("firebase_url", "") ?: "")
    val dbUrl: StateFlow<String> = _dbUrl.asStateFlow()

    private val _userId = MutableStateFlow("")
    val userId: StateFlow<String> = _userId.asStateFlow()

    private val _userName = MutableStateFlow("")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _userColor = MutableStateFlow("")
    val userColor: StateFlow<String> = _userColor.asStateFlow()

    // UI States
    private val _isSimulatorMode = MutableStateFlow(true)
    val isSimulatorMode: StateFlow<Boolean> = _isSimulatorMode.asStateFlow()

    private val _activeRoomId = MutableStateFlow<String>("r_general")
    val activeRoomId: StateFlow<String> = _activeRoomId.asStateFlow()

    private val _activePrivateRecipient = MutableStateFlow<User?>(null)
    val activePrivateRecipient: StateFlow<User?> = _activePrivateRecipient.asStateFlow()

    private val _roomMessages = MutableStateFlow<Map<String, List<Message>>>(emptyMap())
    val roomMessages: StateFlow<Map<String, List<Message>>> = _roomMessages.asStateFlow()

    // Key: chatId (lexicographically joined user IDs e.g. "user1_user2")
    private val _privateMessages = MutableStateFlow<Map<String, List<Message>>>(emptyMap())
    val privateMessages: StateFlow<Map<String, List<Message>>> = _privateMessages.asStateFlow()

    private val _onlineUsers = MutableStateFlow<List<User>>(emptyList())
    val onlineUsers: StateFlow<List<User>> = _onlineUsers.asStateFlow()

    private val _isConnecting = MutableStateFlow(false)
    val isConnecting: StateFlow<Boolean> = _isConnecting.asStateFlow()

    private val _typingUsers = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val typingUsers: StateFlow<Map<String, Boolean>> = _typingUsers.asStateFlow()

    init {
        // Initialize User Identification inside prefs
        var savedUserId = prefs.getString("user_id", "") ?: ""
        if (savedUserId.isBlank()) {
            savedUserId = "user_${UUID.randomUUID().toString().take(6)}"
            prefs.edit().putString("user_id", savedUserId).apply()
        }
        _userId.value = savedUserId

        var savedUsername = prefs.getString("user_name", "") ?: ""
        if (savedUsername.isBlank()) {
            savedUsername = generateRandomArabicName()
            prefs.edit().putString("user_name", savedUsername).apply()
        }
        _userName.value = savedUsername

        var savedUserColor = prefs.getString("user_color", "") ?: ""
        if (savedUserColor.isBlank()) {
            savedUserColor = generateRandomHexColor()
            prefs.edit().putString("user_color", savedUserColor).apply()
        }
        _userColor.value = savedUserColor

        // Simulator mode defaults to true if there is no URL, else false
        val savedUrl = prefs.getString("firebase_url", "") ?: ""
        _dbUrl.value = savedUrl
        _isSimulatorMode.value = savedUrl.isBlank()

        // Init database collections if URL is present
        refreshOnlineUsers()

        // Start background polling and simulation engine
        startSyncEngine()
        startSimulatorBackgroundActivity()
    }

    private fun generateRandomArabicName(): String {
        val adjectives = listOf("الذكي", "الجميل", "المتفائل", "الهادئ", "المثقف", "الفنان", "الطموح", "الأصيل", "النبيل", "الباسم")
        val nouns = listOf("فارس", "نجم", "محب", "سندباد", "صقر", "غواص", "عابر", "مفكر", "شاعر", "صانع الأمل")
        return "${nouns.random()} ${adjectives.random()}"
    }

    private fun generateRandomHexColor(): String {
        val colors = listOf("#009688", "#00BCD4", "#2196F3", "#3F51B5", "#673AB7", "#9C27B0", "#E91E63", "#4CAF50", "#FF9800", "#FF5722")
        return colors.random()
    }

    fun updateProfile(name: String, colorHex: String) {
        val cleanName = name.trim().take(30)
        if (cleanName.isNotBlank()) {
            _userName.value = cleanName
            _userColor.value = colorHex
            prefs.edit()
                .putString("user_name", cleanName)
                .putString("user_color", colorHex)
                .apply()

            // Update user in Firebase if enabled
            if (!_isSimulatorMode.value) {
                notifyFirebaseUserPresence()
            }
        }
    }

    fun updateFirebaseUrl(url: String) {
        val cleanUrl = url.trim()
        _dbUrl.value = cleanUrl
        prefs.edit().putString("firebase_url", cleanUrl).apply()

        if (cleanUrl.isBlank()) {
            _isSimulatorMode.value = true
        } else {
            _isSimulatorMode.value = false
            _isConnecting.value = true
            // Trigger quick async connection test
            viewModelScope.launch(Dispatchers.IO) {
                notifyFirebaseUserPresence()
                withContext(Dispatchers.Main) {
                    _isConnecting.value = false
                }
            }
        }
        refreshOnlineUsers()
    }

    fun setSimulatorMode(enabled: Boolean) {
        _isSimulatorMode.value = enabled
        refreshOnlineUsers()
    }

    private fun refreshOnlineUsers() {
        if (_isSimulatorMode.value) {
            _onlineUsers.value = mockBots
        } else {
            viewModelScope.launch(Dispatchers.IO) {
                val fetched = firebaseService.fetchUsers(_dbUrl.value)
                val currentMe = User(
                    id = _userId.value,
                    username = _userName.value,
                    avatarColor = _userColor.value,
                    lastActive = System.currentTimeMillis(),
                    isOnline = true
                )
                // Filter out offline ones (lastActive > 2 mins old is offline)
                val activeOnly = fetched.filter { 
                    it.id != _userId.value && (System.currentTimeMillis() - it.lastActive < 120000) 
                }
                _onlineUsers.value = listOf(currentMe) + activeOnly
            }
        }
    }

    private fun notifyFirebaseUserPresence() {
        val url = _dbUrl.value
        if (url.isBlank()) return
        
        val userObj = User(
            id = _userId.value,
            username = _userName.value,
            avatarColor = _userColor.value,
            lastActive = System.currentTimeMillis(),
            isOnline = true
        )
        viewModelScope.launch(Dispatchers.IO) {
            firebaseService.sendPresence(url, userObj)
        }
    }

    // Enter a group room
    fun selectRoom(roomId: String) {
        _activeRoomId.value = roomId
        _activePrivateRecipient.value = null
    }

    // Enter a private message
    fun selectPrivateUser(user: User) {
        _activePrivateRecipient.value = user
        // Ensure this user is present in private users if not existed
    }

    fun getChatId(userId1: String, userId2: String): String {
        return if (userId1 < userId2) "${userId1}_${userId2}" else "${userId2}_${userId1}"
    }

    fun sendMessage(text: String) {
        val msgText = text.trim()
        if (msgText.isBlank()) return

        val roomId = _activeRoomId.value
        val recipient = _activePrivateRecipient.value

        val newMsg = Message(
            id = UUID.randomUUID().toString(),
            senderId = _userId.value,
            senderName = _userName.value,
            senderColor = _userColor.value,
            content = msgText,
            timestamp = System.currentTimeMillis(),
            roomId = if (recipient == null) roomId else null,
            recipientId = recipient?.id,
            isPrivate = recipient != null
        )

        if (recipient == null) {
            // Send to Active Room
            val currentList = _roomMessages.value[roomId] ?: emptyList()
            _roomMessages.value = _roomMessages.value + (roomId to (currentList + newMsg))

            if (_isSimulatorMode.value) {
                // If simulator user sent message, trigger bot interaction sometimes
                triggerBotRoomReply(roomId, msgText)
            } else {
                viewModelScope.launch(Dispatchers.IO) {
                    firebaseService.sendRoomMessage(_dbUrl.value, roomId, newMsg)
                }
            }
        } else {
            // Send Private Message
            val chatId = getChatId(_userId.value, recipient.id)
            val currentList = _privateMessages.value[chatId] ?: emptyList()
            _privateMessages.value = _privateMessages.value + (chatId to (currentList + newMsg))

            if (_isSimulatorMode.value || recipient.id.startsWith("user_bot")) {
                // Trigger bot direct replying to private message
                triggerBotPrivateReply(recipient.id, msgText)
            } else {
                viewModelScope.launch(Dispatchers.IO) {
                    firebaseService.sendPrivateMessage(_dbUrl.value, chatId, newMsg)
                }
            }
        }
    }

    /**
     * Start the synchronization worker
     */
    private fun startSyncEngine() {
        viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                try {
                    if (!_isSimulatorMode.value && _dbUrl.value.isNotBlank()) {
                        notifyFirebaseUserPresence()
                        
                        // Sync room messages for active room
                        val currentRoom = _activeRoomId.value
                        val recipient = _activePrivateRecipient.value
                        
                        if (recipient == null) {
                            val messages = firebaseService.fetchRoomMessages(_dbUrl.value, currentRoom)
                            if (messages.isNotEmpty()) {
                                _roomMessages.value = _roomMessages.value + (currentRoom to messages)
                            }
                        } else {
                            val chatId = getChatId(_userId.value, recipient.id)
                            val messages = firebaseService.fetchPrivateMessages(_dbUrl.value, chatId)
                            if (messages.isNotEmpty()) {
                                _privateMessages.value = _privateMessages.value + (chatId to messages)
                            }
                        }

                        // Sync Online Users
                        val fetchedUsers = firebaseService.fetchUsers(_dbUrl.value)
                        val now = System.currentTimeMillis()
                        
                        // Merge with our simulator bots if we want some activity
                        val activeUsersFiltered = fetchedUsers.filter { 
                            it.id != _userId.value && (now - it.lastActive < 120000) 
                        }
                        
                        _onlineUsers.value = listOf(
                            User(_userId.value, _userName.value, _userColor.value, now, true)
                        ) + activeUsersFiltered
                    }
                } catch (e: Exception) {
                    Log.e("ChatViewModel", "Sync Engine Exception: ${e.message}")
                }
                delay(2500) // Poll every 2.5 seconds
            }
        }
    }

    /**
     * Simulation activity: generates random posts in rooms to look fully alive!
     */
    private fun startSimulatorBackgroundActivity() {
        viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                delay(Random.nextLong(15000, 25000)) // Every 15-25 seconds, simulated message
                if (_isSimulatorMode.value) {
                    val targetRoom = rooms.random().id
                    val botUser = mockBots.random()
                    // Create simulated room message
                    val cleanText = if (targetRoom == "r_tech") {
                        listOf(
                            "الرموز البرمجية جيدة الصنع هي أرقى مستويات الإبداع.",
                            "نظام Compose يسهل كتابة واجهات مذهلة وسرعة استجابة مذهلة.",
                            "التحديثات الأخيرة لفايربيس خرافية وتخدم المطورين بشكل مثالي.",
                            "كوتلان (Kotlin) أصبحت اللغة المفضلة لمعظم مطوري الأندرويد."
                        ).random()
                    } else if (targetRoom == "r_literature") {
                        listOf(
                            "وما التأنيث لاسم الشمس عيبٌ... ولا التذكير فخرٌ للهلالِ",
                            "جمال الخط ونقاء الفكر، تلك هي البلاغة الحقة.",
                            "تحدثوا بالجميل أو صمتوا بالوقار، فما الكلمات إلا مرايا النفوس."
                        ).random()
                    } else if (targetRoom == "r_sports") {
                        listOf(
                            "الدوري مليء بالمفاجآت هذا الموسم، لا يمكن التنبؤ بالبطل!",
                            "المستويات الفنية اليوم مذهلة للغاية، المتعة مضمونة.",
                            "مقهى الرياضة هو مكاني المفضل في هذا التطبيق النقاشات ساخنة!"
                        ).random()
                    } else {
                        generalBotRandomTalk.random()
                    }

                    val simMsg = Message(
                        id = UUID.randomUUID().toString(),
                        senderId = botUser.id,
                        senderName = botUser.username,
                        senderColor = botUser.avatarColor,
                        content = cleanText,
                        timestamp = System.currentTimeMillis(),
                        roomId = targetRoom
                    )

                    val currentList = _roomMessages.value[targetRoom] ?: emptyList()
                    _roomMessages.value = _roomMessages.value + (targetRoom to (currentList + simMsg))
                }
            }
        }
    }

    private fun triggerBotRoomReply(roomId: String, userText: String) {
        viewModelScope.launch(Dispatchers.Default) {
            delay(1500) // Typing lag
            val activeRec = _activePrivateRecipient.value
            if (activeRec != null || _activeRoomId.value != roomId) return@launch // Stop if user changed view

            val bot = mockBots.random()
            val templates = botMessageTemplates[bot.id] ?: generalBotRandomTalk
            val replyText = if (userText.contains("مرحبا") || userText.contains("هلا") || userText.contains("سلام")) {
                "أهلاً بك يا غالي! نوّرت الدردشة في غرفة ${rooms.firstOrNull { it.id == roomId }?.name ?: "الدردشة"}"
            } else {
                templates.random()
            }

            val botMsg = Message(
                id = UUID.randomUUID().toString(),
                senderId = bot.id,
                senderName = bot.username,
                senderColor = bot.avatarColor,
                content = replyText,
                timestamp = System.currentTimeMillis(),
                roomId = roomId
            )

            // Trigger typing effect
            _typingUsers.value = _typingUsers.value + (bot.id to true)
            delay(1200)
            _typingUsers.value = _typingUsers.value - bot.id

            val currentList = _roomMessages.value[roomId] ?: emptyList()
            _roomMessages.value = _roomMessages.value + (roomId to (currentList + botMsg))
        }
    }

    private fun triggerBotPrivateReply(botId: String, userText: String) {
        viewModelScope.launch(Dispatchers.Default) {
            val bot = mockBots.firstOrNull { it.id == botId } ?: return@launch
            
            // Set typing state
            _typingUsers.value = _typingUsers.value + (botId to true)
            delay(2000) // Bot is typing...
            _typingUsers.value = _typingUsers.value - botId

            val replyText = when {
                userText.contains("مرحبا") || userText.contains("هلا") || userText.contains("سلام") -> {
                    "أهلاً وسهلاً بك معي في الخاص! أنا ${bot.username}، يسعدني الحديث معك ومساعدتك في تجربة الشات."
                }
                userText.contains("فاير") || userText.contains("firebase") || userText.contains("سيرفر") -> {
                    "الربط مع فايربيس (Firebase) سهل للغاية! قم بنسخ رابط قاعدة بيانات Realtime Database الخاصة بك، واذهب إلى علامة تبويب الإعدادات ثم الصقه هناك وسيقوم التطبيق بالاتصال فوراً!"
                }
                userText.contains("كيفك") || userText.contains("حالك") || userText.contains("شلونك") -> {
                    "الحمد لله بخير ونعمة! كيف حالك أنت وما هو رأيك في واجهات التطبيق المبنية بـ Jetpack Compose؟"
                }
                else -> {
                    val templates = botMessageTemplates[bot.id] ?: generalBotRandomTalk
                    templates.random()
                }
            }

            val chatId = getChatId(_userId.value, bot.id)
            val botMsg = Message(
                id = UUID.randomUUID().toString(),
                senderId = bot.id,
                senderName = bot.username,
                senderColor = bot.avatarColor,
                content = replyText,
                timestamp = System.currentTimeMillis(),
                recipientId = _userId.value,
                isPrivate = true
            )

            val currentList = _privateMessages.value[chatId] ?: emptyList()
            _privateMessages.value = _privateMessages.value + (chatId to (currentList + botMsg))
        }
    }
}
