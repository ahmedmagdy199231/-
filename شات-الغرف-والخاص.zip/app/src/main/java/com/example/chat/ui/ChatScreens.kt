@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.chat.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chat.model.ChatRoom
import com.example.chat.model.Message
import com.example.chat.model.User
import com.example.chat.viewmodel.ChatViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun ChatMainScreen(viewModel: ChatViewModel) {
    val activeRoomId by viewModel.activeRoomId.collectAsState()
    val activeRecipient by viewModel.activePrivateRecipient.collectAsState()

    val currentMainTab = remember { mutableStateOf(0) } // 0 = Rooms, 1 = Private, 2 = Settings

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F2FA))
    ) {
        // We have two overlay screens for active conversations, or the main dashboard
        AnimatedContent(
            targetState = Triple(activeRoomId, activeRecipient, currentMainTab.value),
            transitionSpec = {
                fadeIn() with fadeOut()
            }
        ) { state ->
            val (roomId, recipient, tab) = state

            // If we are talking to a private user
            if (recipient != null) {
                ActivePrivateChatScreen(
                    recipient = recipient,
                    viewModel = viewModel,
                    onBack = { 
                        // To go back, we select general room or reset recipient
                        viewModel.selectRoom("r_general")
                    }
                )
            } else {
                // Check if user has entered room details (beyond the list)
                // In our current single-screen structure, we can show active room chats in a modal/sub-page 
                // OR we can embed the active room directly, and when user clicks a room card, we transition to it!
                // Let's hold a state "currentOpenRoom" to navigate into high detail messaging view!
                var currentOpenRoomId by remember { mutableStateOf<String?>(null) }

                if (currentOpenRoomId != null) {
                    val activeRoom = viewModel.rooms.first { it.id == currentOpenRoomId }
                    ActiveRoomChatScreen(
                        room = activeRoom,
                        viewModel = viewModel,
                        onBack = { currentOpenRoomId = null }
                    )
                } else {
                    // Normal tab bar view
                    Scaffold(
                        topBar = {
                            CenterAlignedTopAppBar(
                                title = {
                                    Text(
                                        "شـات ديـوان العرب",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                        color = Color(0xFF1D1B20)
                                    )
                                },
                                actions = {
                                    val isSim by viewModel.isSimulatorMode.collectAsState()
                                    if (isSim) {
                                        Badge(
                                            containerColor = Color(0xFFD0BCFF),
                                            modifier = Modifier.padding(end = 12.dp)
                                        ) {
                                            Text(
                                                "محاكاة تجريبية",
                                                color = Color(0xFF21005D),
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    } else {
                                        Badge(
                                            containerColor = Color(0xFF6750A4),
                                            modifier = Modifier.padding(end = 12.dp)
                                        ) {
                                            Text(
                                                "فايربيس متصل",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                },
                                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                    containerColor = Color(0xFFFEF7FF)
                                )
                            )
                        },
                        bottomBar = {
                            NavigationBar(
                                containerColor = Color(0xFFF3EDF7),
                                modifier = Modifier.navigationBarsPadding()
                            ) {
                                NavigationBarItem(
                                    selected = tab == 0,
                                    onClick = { currentMainTab.value = 0 },
                                    icon = { Icon(Icons.Default.Home, contentDescription = "الغرف") },
                                    label = { Text("غرف الدردشة", fontWeight = FontWeight.Bold) }
                                )
                                NavigationBarItem(
                                    selected = tab == 1,
                                    onClick = { currentMainTab.value = 1 },
                                    icon = { Icon(Icons.Default.Person, contentDescription = "خاص") },
                                    label = { Text("المتصلون / خاص", fontWeight = FontWeight.Bold) }
                                )
                                NavigationBarItem(
                                    selected = tab == 2,
                                    onClick = { currentMainTab.value = 2 },
                                    icon = { Icon(Icons.Default.Settings, contentDescription = "الإعدادات") },
                                    label = { Text("الإعدادات", fontWeight = FontWeight.Bold) }
                                )
                            }
                        },
                        containerColor = Color.Transparent
                    ) { padding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(padding)
                        ) {
                            when (tab) {
                                0 -> RoomsTab(
                                    viewModel = viewModel,
                                    onRoomClick = { selectedRoomId ->
                                        viewModel.selectRoom(selectedRoomId)
                                        currentOpenRoomId = selectedRoomId
                                    }
                                )
                                1 -> PrivateChatsTab(
                                    viewModel = viewModel,
                                    onPersonClick = { user ->
                                        viewModel.selectPrivateUser(user)
                                    }
                                )
                                2 -> SettingsTab(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RoomsTab(viewModel: ChatViewModel, onRoomClick: (String) -> Unit) {
    val roomMessages by viewModel.roomMessages.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8DEF8)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "أهلاً بك في الدردشة الكتابية المباشرة! 👋",
                        color = Color(0xFF21005D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "انضم إلى الغرف الجماعية أدناه وتبادل الأفكار والخبرات مع أصدقائك بخصوصية تامة، أو تصفح قائمة الأعضاء لبدء شات خاص وسري معهم.",
                        color = Color(0xFF49454F),
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                        textAlign = TextAlign.Right
                    )
                }
            }
        }

        items(viewModel.rooms) { room ->
            val msgs = roomMessages[room.id] ?: emptyList()
            val lastMsgText = msgs.lastOrNull()?.content ?: "لا توجد رسائل سابقة في هذه الغرفة"
            val lastMsgSender = msgs.lastOrNull()?.senderName ?: ""

            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EDF7)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onRoomClick(room.id) }
                    .border(1.dp, Color(0xFFEADDFF), RoundedCornerShape(28.dp)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Emoji / Visual Indicator instead of plain icons
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFFD0BCFF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = getEmojiForRoom(room.id),
                            fontSize = 24.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = room.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF1D1B20)
                            )
                            Badge(
                                containerColor = Color(0xFFE8DEF8)
                            ) {
                                Text(
                                    "عام جماعي",
                                    color = Color(0xFF6750A4),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Text(
                            text = room.description,
                            fontSize = 12.sp,
                            color = Color(0xFF49454F),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Render last message highlight
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFFEF7FF), RoundedCornerShape(12.dp))
                                .border(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (lastMsgSender.isNotBlank()) "$lastMsgSender: " else "",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFF6750A4)
                            )
                            Text(
                                text = lastMsgText,
                                fontSize = 11.sp,
                                color = Color(0xFF49454F),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrivateChatsTab(viewModel: ChatViewModel, onPersonClick: (User) -> Unit) {
    val onlineUsers by viewModel.onlineUsers.collectAsState()
    val currentUserId by viewModel.userId.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "الأعضاء النشطون حالياً المتصلون بالخادم:",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFF6750A4),
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (onlineUsers.none { it.id != currentUserId }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Text("📍", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "لا يوجد مستخدمين آخرين متصلين حالياً بالخادم.",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF49454F),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "بإمكانك تفعيل وضع (المحاكاة للتجربة) في صفحة الإعدادات لتظهر لك الحسابات الآلية الذكية وتتحدث معها في الخاص بصورة تفاعلية ممتازة!",
                        fontSize = 12.sp,
                        color = Color(0xFF49454F).copy(alpha = 0.8f),
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(onlineUsers.filter { it.id != currentUserId }) { user ->
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EDF7)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPersonClick(user) }
                            .border(1.dp, Color(0xFFEADDFF), RoundedCornerShape(24.dp)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // User Avatar
                            val avatarColor = try {
                                Color(android.graphics.Color.parseColor(user.avatarColor))
                            } catch (e: Exception) {
                                Color(0xFF6750A4)
                            }

                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(avatarColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = user.username.firstOrNull()?.toString()?.uppercase() ?: "?",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = user.username,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color(0xFF1D1B20)
                                    )
                                    if (user.id.startsWith("user_bot")) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Badge(containerColor = Color(0xFFE8DEF8)) {
                                            Text(
                                                "آلي ذكي",
                                                color = Color(0xFF6750A4),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF4CAF50))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "متصل بالخادم ويستمع إليك",
                                        fontSize = 11.sp,
                                        color = Color(0xFF49454F)
                                    )
                                }
                            }

                            // Private action button
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE8DEF8)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("✉️", fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTab(viewModel: ChatViewModel) {
    val currentName by viewModel.userName.collectAsState()
    val currentColorHex by viewModel.userColor.collectAsState()
    val savedUrl by viewModel.dbUrl.collectAsState()
    val simulatorMode by viewModel.isSimulatorMode.collectAsState()

    var nameInput by remember { mutableStateOf(currentName) }
    var urlInput by remember { mutableStateOf(savedUrl) }

    val colorsPalette = listOf(
        "#6750A4", "#D0BCFF", "#2196F3", "#3F51B5", "#673AB7", 
        "#9C27B0", "#E91E63", "#4CAF50", "#FF9800", "#FF5722"
    )

    var nameSavedFeedback by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        // Section: Personal Profile Setup
        item {
            Text(
                "الملف التعريفي واللقب العربي الشخصي:",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF6750A4)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EDF7)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFEADDFF), RoundedCornerShape(24.dp)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Profile Preview
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val parsedColor = try {
                            Color(android.graphics.Color.parseColor(currentColorHex))
                        } catch (e: Exception) {
                            Color(0xFF6750A4)
                        }

                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(parsedColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = nameInput.firstOrNull()?.toString()?.uppercase() ?: "?",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = currentName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF1D1B20)
                            )
                            Text(
                                text = "مستواك: عضو مميز وفعال شات ديوان",
                                fontSize = 11.sp,
                                color = Color(0xFF49454F)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("اللقب في غرف الشات") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            viewModel.updateProfile(nameInput, currentColorHex)
                            nameSavedFeedback = true
                        }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6750A4),
                            focusedLabelColor = Color(0xFF6750A4),
                            unfocusedBorderColor = Color(0xFFCAC4D0)
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        "اختر لون السحابة الرمزية الخاصة بك:",
                        fontSize = 12.sp,
                        color = Color(0xFF1D1B20),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        colorsPalette.take(5).forEach { colorString ->
                            val color = Color(android.graphics.Color.parseColor(colorString))
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .clickable {
                                        viewModel.updateProfile(nameInput, colorString)
                                    }
                                    .border(
                                        width = if (currentColorHex == colorString) 3.dp else 0.dp,
                                        color = if (currentColorHex == colorString) Color(0xFF1D1B20) else Color.Transparent,
                                        shape = CircleShape
                                    )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        colorsPalette.drop(5).forEach { colorString ->
                            val color = Color(android.graphics.Color.parseColor(colorString))
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .clickable {
                                        viewModel.updateProfile(nameInput, colorString)
                                    }
                                    .border(
                                        width = if (currentColorHex == colorString) 3.dp else 0.dp,
                                        color = if (currentColorHex == colorString) Color(0xFF1D1B20) else Color.Transparent,
                                        shape = CircleShape
                                    )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            viewModel.updateProfile(nameInput, currentColorHex)
                            nameSavedFeedback = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6750A4)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("حفظ الملف التعريفي 💾", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    if (nameSavedFeedback) {
                        Text(
                            "تم تحديث بيانات اللقب الخاص بك بنجاح في الشات!",
                            color = Color(0xFF6750A4),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Section: Connection Mode Settings (Interactive Firebase Connection Setup)
        item {
            Text(
                "ربط الشات بسيرفر الفايربيس (Firebase):",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF6750A4)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EDF7)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFEADDFF), RoundedCornerShape(24.dp)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Checkbox or slider for Simulation vs Firebase
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "تفعيل وضع محاكاة البوت الذكي",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF1D1B20)
                            )
                            Text(
                                "للحديث المفترض مع مستخدمين آليين (مفيد جداً قبل وضع قاعدة البيانات)",
                                fontSize = 11.sp,
                                color = Color(0xFF49454F),
                                lineHeight = 15.sp
                            )
                        }
                        Switch(
                            checked = simulatorMode,
                            onCheckedChange = { viewModel.setSimulatorMode(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF6750A4))
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    Text(
                        "رابط قاعدة بيانات فايربيس (Realtime Database URL):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFF1D1B20)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        placeholder = { Text("https://[your-db]-rtdb.firebaseio.com") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6750A4),
                            unfocusedBorderColor = Color(0xFFCAC4D0)
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(textAlign = TextAlign.Left)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.updateFirebaseUrl(urlInput)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (urlInput.isBlank()) Color.Gray else Color(0xFF6750A4)
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = urlInput.isNotBlank()
                    ) {
                        Text("ربط وتفعيل الخادم الفوري 🔗", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Helpful tutorial
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8DEF8)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                "كيف تقوم بإنشاء فايربيس وربطه مع التطبيق مجاناً؟ 💡",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF21005D)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "1. اذهب وتوجه إلى console.firebase.google.com\n" +
                                        "2. قم بإنشاء مشروع جديد (New Project).\n" +
                                        "3. توجه لخيار (Build -> Realtime Database) ثم تفعيلها.\n" +
                                        "4. في تبويب (Rules)، قم بتغيير القيمة لكلا الـ read والـ write إلى true لتحصيل إمكانية الكتابة الفورية بدون قيود.\n" +
                                        "5. انسخ الرابط العلوي المقيد في المنصة والصقه في الحقل أعلاه لتتمتع بالمزامنة!",
                                fontSize = 10.sp,
                                color = Color(0xFF49454F),
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/*
}�ذهب وتوجه إلى console.firebase.google.com\n" +
                                        "2. قم بإنشاء مشروع جديد (New Project).\n" +
                                        "3. توجه لخيار (Build -> Realtime Database) ثم تفعيلها.\n" +
                                        "4. في تبويب (Rules)، قم بتغيير القيمة لكلا الـ read والـ write إلى true لتحصيل إمكانية الكتابة الفورية بدون قيود.\n" +
                                        "5. انسخ الرابط العلوي المقيد في المنصة والصقه في الحقل أعلاه لتتمتع بالمزامنة!",
                                fontSize = 10.sp,
                                color = Color(0xFF004D40).copy(alpha = 0.85f),
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
*/

@Composable
fun ActiveRoomChatScreen(
    room: ChatRoom,
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val roomMessages by viewModel.roomMessages.collectAsState()
    val typingUsers by viewModel.typingUsers.collectAsState()
    val currentUserId by viewModel.userId.collectAsState()

    val msgs = roomMessages[room.id] ?: emptyList()
    var textInput by remember { mutableStateOf("") }

    val listState = rememberLazyListState()

    // Auto-scroll to bottom of messages
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) {
            listState.animateScrollToItem(msgs.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(room.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1D1B20))
                        Text("دردشة جماعية مباشرة", fontSize = 11.sp, color = Color(0xFF49454F))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color(0xFF1D1B20))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFFEF7FF))
            )
        },
        containerColor = Color(0xFFF7F2FA)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Screen Messages Body
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (msgs.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.8f)),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("💬", fontSize = 32.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "أرسل أول رسالة في الغرفة لتبدأ الحوار!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.DarkGray,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(msgs) { msg ->
                            val isMe = msg.senderId == currentUserId
                            SpeechBubble(message = msg, isMe = isMe)
                        }
                    }
                }
            }

            // Typing Indicator Area
            val typingBots = typingUsers.keys.filter { it.startsWith("user_bot") }
            if (typingBots.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "جاري تدوين الرد من المستخدمين الآليين...",
                        fontSize = 11.sp,
                        color = Color(0xFF6750A4),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Chat Input Text Bar
            Card(
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF7FF)),
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("اكتب رسالتك هنا...") },
                        maxLines = 3,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6750A4),
                            unfocusedBorderColor = Color(0xFFCAC4D0)
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Send
                        ),
                        keyboardActions = KeyboardActions(onSend = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            }
                        })
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF6750A4))
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "إرسال",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ActivePrivateChatScreen(
    recipient: User,
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val privateMessages by viewModel.privateMessages.collectAsState()
    val typingUsers by viewModel.typingUsers.collectAsState()
    val currentUserId by viewModel.userId.collectAsState()

    val chatId = viewModel.getChatId(currentUserId, recipient.id)
    val msgs = privateMessages[chatId] ?: emptyList()
    var textInput by remember { mutableStateOf("") }

    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) {
            listState.animateScrollToItem(msgs.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val parsedColor = try {
                            Color(android.graphics.Color.parseColor(recipient.avatarColor))
                        } catch (e: Exception) {
                            Color(0xFF008080)
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(parsedColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = recipient.username.firstOrNull()?.toString()?.uppercase() ?: "?",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(recipient.username, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1D1B20))
                            Text("دردشة خاصة سرية آمنة", fontSize = 10.sp, color = Color(0xFF49454F))
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color(0xFF1D1B20))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFFEF7FF))
            )
        },
        containerColor = Color(0xFFF7F2FA)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Security Lock Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFE8DEF8))
                    .padding(vertical = 4.dp, horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    "🔒 الرسائل مشفرة من طرف لآخر في قاعدة بيانات الفايربيس",
                    fontSize = 10.sp,
                    color = Color(0xFF6750A4),
                    textAlign = TextAlign.Center
                )
            }

            // Message Board
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (msgs.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.85f)),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("💬", fontSize = 36.sp)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    "بث أول همسة ودية في دردشتكم الخاصة!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.DarkGray,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "أرسل رسالة مخصصة لـ ${recipient.username}. سيتم مزامنة الشات لحظة بلحظة.",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(msgs) { msg ->
                            val isMe = msg.senderId == currentUserId
                            SpeechBubble(message = msg, isMe = isMe)
                        }
                    }
                }
            }

            // Typing feedback
            if (typingUsers[recipient.id] == true) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "جاري تدوين الرد من ${recipient.username} يكتب الآن...",
                        fontSize = 11.sp,
                        color = Color(0xFF6750A4),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Bottom Input
            Card(
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF7FF)),
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("اكتب رسالة خاصة هادفة...") },
                        maxLines = 3,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6750A4),
                            unfocusedBorderColor = Color(0xFFCAC4D0)
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Send
                        ),
                        keyboardActions = KeyboardActions(onSend = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            }
                        })
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF6750A4))
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "إرسال",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SpeechBubble(message: Message, isMe: Boolean) {
    val formatter = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val formattedTime = formatter.format(Date(message.timestamp))

    val arrangement = if (isMe) Arrangement.End else Arrangement.Start
    val alignment = if (isMe) Alignment.End else Alignment.Start

    val bubbleShape = if (isMe) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 2.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 2.dp, bottomEnd = 16.dp)
    }

    val bubbleBg = if (isMe) Color(0xFFE8DEF8) else Color(0xFFFEF7FF)
    val textThemeColor = if (isMe) Color(0xFF21005D) else Color(0xFF1D1B20)
    val timeThemeColor = if (isMe) Color(0xFF21005D).copy(alpha = 0.6f) else Color(0xFF49454F).copy(alpha = 0.6f)

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = arrangement
    ) {
        if (!isMe) {
            // Sender Avatar
            val parsedColor = try {
                Color(android.graphics.Color.parseColor(message.senderColor))
            } catch (e: Exception) {
                Color(0xFF6750A4)
            }

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(parsedColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = message.senderName.firstOrNull()?.toString()?.uppercase() ?: "?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(horizontalAlignment = alignment) {
            // Render sender name in room messages if not me
            if (!isMe && message.roomId != null) {
                Text(
                    text = message.senderName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF6750A4),
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp)
                )
            }

            Surface(
                shape = bubbleShape,
                color = bubbleBg,
                shadowElevation = 0.dp,
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .border(1.dp, Color(0xFFEADDFF), bubbleShape)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = message.content,
                        color = textThemeColor,
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        textAlign = TextAlign.Start
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = formattedTime,
                        fontSize = 9.sp,
                        color = timeThemeColor,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }

        if (isMe) {
            Spacer(modifier = Modifier.width(8.dp))
            // Render mini sender indicator or self icon
            val parsedColor = try {
                Color(android.graphics.Color.parseColor(message.senderColor))
            } catch (e: Exception) {
                Color(0xFF6750A4)
            }
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(parsedColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = message.senderName.firstOrNull()?.toString()?.uppercase() ?: "?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

// Map Room ID to beautiful emoji icons
fun getEmojiForRoom(id: String): String {
    return when (id) {
        "r_general" -> "💬"
        "r_tech" -> "💻"
        "r_literature" -> "📖"
        "r_sports" -> "⚽"
        else -> "⭐"
    }
}
