package com.example.chat.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class User(
    val id: String = "",
    val username: String = "",
    val avatarColor: String = "#008080",
    val lastActive: Long = 0L,
    val isOnline: Boolean = true
)

@JsonClass(generateAdapter = true)
data class Message(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val senderColor: String = "#008080",
    val content: String = "",
    val timestamp: Long = 0L,
    val roomId: String? = null,
    val recipientId: String? = null,
    val isPrivate: Boolean = false
)

data class ChatRoom(
    val id: String,
    val name: String,
    val description: String,
    val icon: String // Icon representation name
)
