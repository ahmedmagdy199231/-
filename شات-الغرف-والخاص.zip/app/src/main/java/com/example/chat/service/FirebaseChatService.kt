package com.example.chat.service

import android.util.Log
import com.example.chat.model.Message
import com.example.chat.model.User
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class FirebaseChatService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val messageAdapter = moshi.adapter(Message::class.java)
    private val userAdapter = moshi.adapter(User::class.java)

    // Adapter for Map<String, Message> to handle Firebase RTDB lists representation
    private val messagesMapType = Types.newParameterizedType(Map::class.java, String::class.java, Message::class.java)
    private val messagesMapAdapter = moshi.adapter<Map<String, Message>>(messagesMapType)

    // Adapter for Map<String, User>
    private val usersMapType = Types.newParameterizedType(Map::class.java, String::class.java, User::class.java)
    private val usersMapAdapter = moshi.adapter<Map<String, User>>(usersMapType)

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /**
     * Clears trailing slashes and ensures standard Firebase scheme
     */
    private fun formatDbUrl(baseUrl: String): String? {
        if (baseUrl.isBlank()) return null
        var url = baseUrl.trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        if (url.endsWith("/")) {
            url = url.substring(0, url.length - 1)
        }
        return url
    }

    /**
     * Send presence status to Firebase
     */
    fun sendPresence(databaseUrl: String, user: User): Boolean {
        val base = formatDbUrl(databaseUrl) ?: return false
        val url = "$base/users/${user.id}.json"
        
        return try {
            val json = userAdapter.toJson(user)
            val request = Request.Builder()
                .url(url)
                .put(json.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("FirebaseService", "Failed to update presence: ${response.code}")
                }
                response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Presence network error: ${e.message}")
            false
        }
    }

    /**
     * Get active users list
     */
    fun fetchUsers(databaseUrl: String): List<User> {
        val base = formatDbUrl(databaseUrl) ?: return emptyList()
        val url = "$base/users.json"

        return try {
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val bodyString = response.body?.string() ?: return emptyList()
                if (bodyString == "null") return emptyList()

                val usersMap = usersMapAdapter.fromJson(bodyString) ?: return emptyList()
                usersMap.values.toList()
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Fetch users error: ${e.message}")
            emptyList()
        }
    }

    /**
     * Send Room Message
     */
    fun sendRoomMessage(databaseUrl: String, roomId: String, message: Message): Boolean {
        val base = formatDbUrl(databaseUrl) ?: return false
        val url = "$base/rooms/$roomId/messages.json"

        return try {
            val json = messageAdapter.toJson(message)
            val request = Request.Builder()
                .url(url)
                .post(json.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("FirebaseService", "Room send message failed: ${response.code}")
                }
                response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Room message send error: ${e.message}")
            false
        }
    }

    /**
     * Fetch Room Messages
     */
    fun fetchRoomMessages(databaseUrl: String, roomId: String): List<Message> {
        val base = formatDbUrl(databaseUrl) ?: return emptyList()
        val url = "$base/rooms/$roomId/messages.json"

        return try {
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val bodyString = response.body?.string() ?: return emptyList()
                if (bodyString == "null") return emptyList()

                val messagesMap = messagesMapAdapter.fromJson(bodyString) ?: return emptyList()
                // Map can have sub-IDs, we replace ID with Firebase key if empty
                messagesMap.map { (key, value) ->
                    value.copy(id = key)
                }.sortedBy { it.timestamp }
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Fetch room messages error: ${e.message}")
            emptyList()
        }
    }

    /**
     * Send Private Message
     */
    fun sendPrivateMessage(databaseUrl: String, chatId: String, message: Message): Boolean {
        val base = formatDbUrl(databaseUrl) ?: return false
        val url = "$base/private_messages/$chatId/messages.json"

        return try {
            val json = messageAdapter.toJson(message)
            val request = Request.Builder()
                .url(url)
                .post(json.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("FirebaseService", "Private send message failed: ${response.code}")
                }
                response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Private send error: ${e.message}")
            false
        }
    }

    /**
     * Fetch Private Messages
     */
    fun fetchPrivateMessages(databaseUrl: String, chatId: String): List<Message> {
        val base = formatDbUrl(databaseUrl) ?: return emptyList()
        val url = "$base/private_messages/$chatId/messages.json"

        return try {
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val bodyString = response.body?.string() ?: return emptyList()
                if (bodyString == "null") return emptyList()

                val messagesMap = messagesMapAdapter.fromJson(bodyString) ?: return emptyList()
                messagesMap.map { (key, value) ->
                    value.copy(id = key)
                }.sortedBy { it.timestamp }
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Fetch private messages error: ${e.message}")
            emptyList()
        }
    }
}
